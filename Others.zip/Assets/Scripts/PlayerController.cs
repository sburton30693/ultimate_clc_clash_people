using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    [Header("Attributes")]
    public int cur_hp;
    public int max_hp;
    public int score;
    public float run_speed;
    public float jump_force;
    public int max_jumps;
    private int jumps_left;

    private float move_input;
    private bool platform_collide;

    private PlayerController last_attacker;

    private List<GameObject> cur_standing_objects = new List<GameObject>();

    [Header("Components")]
    public Rigidbody2D rig;
    public Animator animtr;
    public Transform muzzle;
    public PlayerContainerUI container_ui;

    [Header("Combat")]
    public float attack_rate;
    private float last_attack_time;
    public float projectile_speed;
    public GameObject projectile_prefab;


    public void spawn(Vector3 spawn_pos)
    {
        transform.position = spawn_pos;
        rig.velocity = new Vector2(0.0f, 0.0f);
        cur_hp = max_hp;
        last_attacker = null;
    }

    private void FixedUpdate()
    {
        move();

        //Update animation
        animtr.SetBool("is_walking", move_input != 0);
        animtr.SetBool("is_jumping", !is_grounded());

        if (move_input != 0)
        {
            transform.localScale = new Vector3(move_input < 0 ? -1.0f : 1.0f, transform.localScale.y, transform.localScale.z);
        }
    }

    private void move()
    {
        rig.velocity = new Vector2(move_input * run_speed, rig.velocity.y);
    }

    private void jump()
    {
        rig.velocity = new Vector2(rig.velocity.x, 0);
        rig.AddForce(Vector2.up * jump_force, ForceMode2D.Impulse);
    }


    public void OnMoveInput(InputAction.CallbackContext context)
    {
        move_input = context.ReadValue<float>();
    }

    public void OnJumpInput(InputAction.CallbackContext context)
    {
        if (context.phase == InputActionPhase.Performed && jumps_left > 0)
        {
            jumps_left--;
            jump();
        }
    }

    public void OnAttackInput(InputAction.CallbackContext context)
    {
        if (context.phase == InputActionPhase.Performed && Time.time - last_attack_time > 1.0f / attack_rate)
        {
            last_attack_time = Time.time;
            spawn_projectile();
        }
    }

    private void spawn_projectile()
    {
        GameObject projectile = Instantiate(projectile_prefab, muzzle.position, Quaternion.identity);
        projectile.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x * projectile_speed, 0.0f);
        projectile.GetComponent<Fireball>().owner = this;
    }

    public void OnFallInput(InputAction.CallbackContext context)
    {
        platform_collide = false;
    }

    public void OnTauntInput(InputAction.CallbackContext context)
    {
        if (context.phase == InputActionPhase.Performed)
        {
            Debug.Log("'Taunt, Taunt'");
        }
    }

    bool is_grounded()
    {
        return cur_standing_objects.Count > 0;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        foreach (ContactPoint2D contact in collision.contacts)
        {
            if (collision.contacts[0].point.y < transform.position.y)
            {
                jumps_left = max_jumps;
                GetComponentInChildren<ParticleSystem>().Play();

                if (!cur_standing_objects.Contains(collision.gameObject))
                {
                    cur_standing_objects.Add(collision.gameObject);
                    return;
                }
            }
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        GetComponentInChildren<ParticleSystem>().Stop();

        if(cur_standing_objects.Contains(collision.gameObject))
        {
            cur_standing_objects.Remove(collision.gameObject);
        }
    }

    public void TakeDamage(int damage, PlayerController attacker)
    {
        last_attacker = attacker;
        cur_hp -= damage;

        if(cur_hp <= 0)
        {
            PlayerManager.instance.OnPlayerDeath(this, last_attacker);
        }

        //Update UI and health bar
        container_ui.UpdateHealthBar(cur_hp, max_hp);
    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.y < -10)
        {
            PlayerManager.instance.OnPlayerDeath(this, last_attacker);
        }
    }
}
