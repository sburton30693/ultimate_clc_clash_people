using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerManager : MonoBehaviour
{
    public Color[] player_colors;
    public List<PlayerController> players = new List<PlayerController>();
    public Transform[] spawn_points;

    [Header("Component")]
    public GameObject death_effect;
    public GameObject player_container_prefab;
    public Transform player_container_parent;

    public static PlayerManager instance;


    private void Awake()
    {
        instance = this;
    }

    public void OnPlayerJoined(PlayerInput player)
    {
        //Set player color
        player.GetComponentInChildren<SpriteRenderer>().color = player_colors[players.Count];

        //Set player spawn point
        player.GetComponent<PlayerController>().spawn(spawn_points[Random.Range(0, spawn_points.Length)].position);
        players.Add(player.GetComponent<PlayerController>());

        //Create a UI for player
        PlayerContainerUI container_ui = Instantiate(player_container_prefab, player_container_parent).GetComponent<PlayerContainerUI>();
        container_ui.Initialize(player_colors[players.Count - 1]);
        player.GetComponent<PlayerController>().container_ui = container_ui;
    }

    public void OnPlayerLeft(PlayerInput player)
    {
        players.Remove(player.GetComponent<PlayerController>());
    }

    public void OnPlayerDeath(PlayerController player, PlayerController attacker)
    {
        //Spawn death effect
        GameObject effect = Instantiate(death_effect, player.transform.position, Quaternion.identity);
        Gradient color = new Gradient();
        color.SetKeys(new GradientColorKey[] { new GradientColorKey(player.GetComponentInChildren<SpriteRenderer>().color, 0.0f) },
            new GradientAlphaKey[] {new GradientAlphaKey(1.0f, 0.0f)});
        effect.GetComponent<ParticleSystem>().trails.colorOverLifetime = color;
        Destroy(effect, 2.0f);
        
        //Increase Score for attacker
        if(attacker != null)
        {
            attacker.score++;
            attacker.container_ui.UpdateScoreText(attacker.score);
        } 
        else
        {
            player.score -= player.score - 1 >= 0 ? 1 : 0;
            player.container_ui.UpdateScoreText(player.score);
        }


        //Respawn player
        player.spawn(spawn_points[Random.Range(0, spawn_points.Length)].position);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
