using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerContainerUI : MonoBehaviour
{
    public TextMeshProUGUI score_text;
    public Image health_bar_fill;

    public void Initialize(Color color)
    {
        score_text.color = color;
        health_bar_fill.color = color;

        score_text.text = "0";
        health_bar_fill.fillAmount = 1.0f;
    }

    public void UpdateScoreText(int score)
    {
        score_text.text = score.ToString();
    }

    public void UpdateHealthBar(int current_hp, int max_hp)
    {
        float percent_health = (float)current_hp / (float)max_hp;
        health_bar_fill.fillAmount = percent_health;
    }
}
