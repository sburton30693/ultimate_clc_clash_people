using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void On_Click(string next_scene)
    {
        SceneManager.LoadScene(next_scene);
    }

    public void On_Quit()
    {
        Application.Quit();
    }
}
